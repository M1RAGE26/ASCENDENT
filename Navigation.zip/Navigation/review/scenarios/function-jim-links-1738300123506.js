(function(window, undefined) {

  var jimLinks = {
    "50ca79ab-3a72-488a-9903-bfa11656d7be" : {
      "Button_4" : [
        "22c3d5d0-4321-4199-9976-39f9b9724fb8"
      ],
      "Path_11" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "179de613-e0a2-4397-9e04-2c6ad6b97ee9" : {
      "Button_4" : [
        "22c3d5d0-4321-4199-9976-39f9b9724fb8"
      ],
      "Path_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "22c3d5d0-4321-4199-9976-39f9b9724fb8" : {
      "Button_1" : [
        "50ca79ab-3a72-488a-9903-bfa11656d7be"
      ],
      "Path_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Button_1" : [
        "50ca79ab-3a72-488a-9903-bfa11656d7be"
      ],
      "Button_2" : [
        "179de613-e0a2-4397-9e04-2c6ad6b97ee9"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);